using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace MANAGER
{
    public class RandomEventManager : Singleton<RandomEventManager>
    {

    }
}


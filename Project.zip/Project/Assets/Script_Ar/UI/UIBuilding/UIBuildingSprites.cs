using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace UIBUILDING
{
    public class UIBuildingSprites
    {
        public List<string> BuildingItemSpriteNames = new List<string>()
        {
            "StoneHarvester",
            "GoldHarvester",
            "ProducingBuilding&DefendBuilding",
            "ProducingBuilding&DefendBuilding",//�������������������زģ����ڸ���
            "WoodHarvester",
         };

        public List<Sprite> sprites = new List<Sprite>() { };

        public UIBuildingSprites() 
        {
            foreach (string name in this.BuildingItemSpriteNames)
            {
                string path = PathConfig.GetBuildingItemSpritePath(name);
                Sprite sp = Resources.Load<Sprite>(path);
                this.sprites.Add(sp);
            }

        }
    }
}